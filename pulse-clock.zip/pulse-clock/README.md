# Pulse — Clock App

A responsive, dependency-free clock web app with a digital clock, analog dial, local timezone display, 12/24-hour format toggle, light/dark theme, stopwatch with lap tracking, and countdown timer.

## Run locally
Open `index.html` in a modern browser. No build step or dependencies are required.

## Deploy with GitHub Pages
1. Upload the contents of this folder to the root of a GitHub repository.
2. Open **Settings → Pages**.
3. Under **Build and deployment**, choose **GitHub Actions** if the deployment workflow is included, or **Deploy from a branch** and select `main` plus `/(root)`.
4. If using GitHub Actions, the workflow in `.github/workflows/deploy.yml` deploys on pushes to `main`.

The app uses your browser's local time and works on mobile and desktop.
