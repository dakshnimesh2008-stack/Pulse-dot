package com.example.pulsedot

import android.content.Context
import android.graphics.*
import android.view.View

/** The floating dot: dark disc, ring colored by heat, label inside. */
class DotView(c: Context) : View(c) {
    var label = "--"; var ring = Color.parseColor("#7FE0D0"); var pulse = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = c.resources.displayMetrics.density
    private var phase = 0f
    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension((54 * d).toInt(), (54 * d).toInt())
    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        if (pulse) { phase = (phase + 0.08f) % 1f; p.style = Paint.Style.FILL; p.color = ring; p.alpha = (90 * (1 - phase)).toInt()
            c.drawCircle(cx, cy, cx * (0.7f + 0.3f * phase), p); p.alpha = 255; postInvalidateOnAnimation() }
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#0F1A22"); c.drawCircle(cx, cy, cx - 4 * d, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = 4 * d; p.color = ring; c.drawCircle(cx, cy, cx - 4 * d, p)
        p.style = Paint.Style.FILL; p.color = Color.WHITE; p.textAlign = Paint.Align.CENTER
        p.textSize = (if (label.length > 3) 13 else 17) * d; p.typeface = Typeface.DEFAULT_BOLD
        c.drawText(label, cx, cy + p.textSize / 3f, p)
    }
}

/** Tiny line graph of recent values. */
class GraphView(c: Context) : View(c) {
    var values: List<Float> = emptyList(); var maxV = 120f; var line = Color.parseColor("#FFB347")
    private val p = Paint(Paint.ANTI_ALIAS_FLAG); private val d = c.resources.displayMetrics.density
    override fun onDraw(c: Canvas) {
        p.style = Paint.Style.FILL; p.color = Color.parseColor("#1B2A35"); c.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), 6 * d, 6 * d, p)
        if (values.size < 2) return
        p.style = Paint.Style.STROKE; p.strokeWidth = 2 * d; p.color = line
        val path = Path()
        values.forEachIndexed { i, v ->
            val x = i / 59f * width; val y = height - (v.coerceIn(0f, maxV) / maxV) * (height - 6 * d) - 3 * d
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        c.drawPath(path, p)
    }
}
