package com.example.pulsedot

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.*
import android.view.*
import android.widget.*
import java.io.File
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var dot: DotView
    private lateinit var panel: LinearLayout
    private lateinit var graph: GraphView
    private val rows = LinkedHashMap<String, TextView>()
    private val h = Handler(Looper.getMainLooper())
    private val history = ArrayList<Float>()
    private var frames = 0; private var fps = 0; private var dotMode = 0
    private var minT = 99f; private var maxT = 0f; private var minF = 999; private var maxF = 0
    private var lastIdle = -1L; private var lastTotal = 0L; private var lastApp = 0L; private var lastWall = 0L
    private var temp = 0f
    private val d get() = resources.displayMetrics.density

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(t: Long) { frames++; Choreographer.getInstance().postFrameCallback(this) }
    }
    private val tick = object : Runnable {
        override fun run() { update(); h.postDelayed(this, 1000) }
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("pd", "PulseDot", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "pd").setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("PulseDot is running").setContentText("Tap the floating dot to see stats").build()
        startForeground(1, n)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        build()
        Choreographer.getInstance().postFrameCallback(frameCb)
        h.post(tick)
    }

    private fun build() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        dot = DotView(this)
        root.addView(dot)
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE
            setBackgroundColor(Color.parseColor("#E6101C26"))
            setPadding((14 * d).toInt(), (12 * d).toInt(), (14 * d).toInt(), (12 * d).toInt())
            layoutParams = LinearLayout.LayoutParams((270 * d).toInt(), -2).apply { topMargin = (6 * d).toInt() }
        }
        graph = GraphView(this).apply { layoutParams = LinearLayout.LayoutParams(-1, (52 * d).toInt()) }
        panel.addView(graph)
        for (k in listOf("FPS (this overlay)", "Screen refresh", "Temperature", "Thermal state", "Battery", "CPU", "RAM", "Storage free", "Network", "Session range", "Uptime")) addRow(k)
        val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, (10 * d).toInt(), 0, 0) }
        fun b(t: String, f: () -> Unit) = Button(this).apply {
            text = t; textSize = 12f; setOnClickListener { f() }
            layoutParams = LinearLayout.LayoutParams(0, (40 * d).toInt(), 1f)
        }
        btns.addView(b("Copy") { copySnapshot() })
        btns.addView(b("Reset") { minT = 99f; maxT = 0f; minF = 999; maxF = 0; history.clear() })
        btns.addView(b("Stop") { stopSelf() })
        panel.addView(btns)
        root.addView(panel)

        lp = WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = (12 * d).toInt(); y = (140 * d).toInt() }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        dot.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
            val gd = GestureDetector(this@OverlayService, object : GestureDetector.SimpleOnGestureListener() {
                override fun onDown(e: MotionEvent) = true
                override fun onSingleTapUp(e: MotionEvent): Boolean { if (!moved) toggle(); return true }
                override fun onLongPress(e: MotionEvent) { if (!moved) { dotMode = (dotMode + 1) % 4; update() } }
            })
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                gd.onTouchEvent(e)
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - tx; val dy = e.rawY - ty
                        if (abs(dx) > slop || abs(dy) > slop) moved = true
                        if (moved) { lp.x = (sx + dx).toInt(); lp.y = (sy + dy).toInt(); wm.updateViewLayout(root, lp) }
                    }
                }
                return true
            }
        })
        wm.addView(root, lp)
    }

    private fun addRow(label: String) {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, (4 * d).toInt(), 0, (4 * d).toInt()) }
        r.addView(TextView(this).apply { text = label; textSize = 12f; setTextColor(Color.parseColor("#8FA6B2")); layoutParams = LinearLayout.LayoutParams(0, -2, 1f) })
        val v = TextView(this).apply { text = "--"; textSize = 14f; setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD); gravity = Gravity.END }
        r.addView(v); panel.addView(r); rows[label] = v
    }

    private fun toggle() { panel.visibility = if (panel.visibility == View.GONE) View.VISIBLE else View.GONE }

    private fun heatColor(t: Float) = Color.parseColor(when { t < 36 -> "#7FE0D0"; t < 40 -> "#FFD166"; t < 43 -> "#FF9F43"; else -> "#FF5A4F" })

    private fun update() {
        fps = frames; frames = 0
        if (fps > 0) { minF = minOf(minF, fps); maxF = maxOf(maxF, fps) }
        history.add(fps.toFloat()); if (history.size > 60) history.removeAt(0)
        graph.values = history; graph.maxV = (display()?.refreshRate ?: 60f).coerceAtLeast(60f); graph.invalidate()

        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        temp = (bi?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val lvl = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
        val volt = (bi?.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) ?: 0) / 1000f
        val st = bi?.getIntExtra(BatteryManager.EXTRA_STATUS, 0)
        val charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        if (temp > 0) { minT = minOf(minT, temp); maxT = maxOf(maxT, temp) }

        val mi = ActivityManager.MemoryInfo(); getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        val usedMb = (mi.totalMem - mi.availMem) / 1048576; val totMb = mi.totalMem / 1048576
        val sf = StatFs(Environment.getDataDirectory().path)
        val freeGb = sf.availableBytes / 1073741824.0

        val cpu = cpuPercent()
        rows["FPS (this overlay)"]!!.text = "$fps  (low $minF / high $maxF)"
        rows["Screen refresh"]!!.text = "${(display()?.refreshRate ?: 0f).toInt()} Hz"
        rows["Temperature"]!!.apply { text = "%.1f °C".format(temp); setTextColor(heatColor(temp)) }
        rows["Thermal state"]!!.text = thermal()
        rows["Battery"]!!.text = "$lvl%${if (charging) " charging" else ""}  ${"%.2f".format(volt)} V"
        rows["CPU"]!!.text = cpu
        rows["RAM"]!!.text = "$usedMb / $totMb MB"
        rows["Storage free"]!!.text = "%.1f GB".format(freeGb)
        rows["Network"]!!.text = network()
        rows["Session range"]!!.text = if (maxT > 0) "%.1f – %.1f °C".format(minT, maxT) else "--"
        val s = SystemClock.elapsedRealtime() / 1000
        rows["Uptime"]!!.text = "%dh %02dm".format(s / 3600, s % 3600 / 60)

        dot.ring = heatColor(temp); dot.pulse = temp >= 43f
        dot.label = when (dotMode) { 0 -> "$fps"; 1 -> "%.0f°".format(temp); 2 -> cpu.substringBefore('%') + "%"; else -> "${usedMb * 100 / totMb}%" }
        dot.invalidate()
    }

    @Suppress("DEPRECATION")
    private fun display(): Display? = wm.defaultDisplay

    private fun cpuPercent(): String {
        try {
            val l = File("/proc/stat").bufferedReader().use { it.readLine() }.trim().split(Regex("\\s+")).drop(1).map { it.toLong() }
            val idle = l[3] + l[4]; val total = l.sum()
            val r = if (lastIdle >= 0 && total > lastTotal) ((total - lastTotal) - (idle - lastIdle)) * 100 / (total - lastTotal) else -1
            lastIdle = idle; lastTotal = total
            if (r >= 0) return "$r% (system)"
        } catch (_: Exception) { /* blocked on Android 8+; fall back to this app only */ }
        val cpu = Process.getElapsedCpuTime(); val wall = SystemClock.elapsedRealtime()
        val r = if (lastWall > 0) (cpu - lastApp) * 100 / maxOf(1, wall - lastWall) / Runtime.getRuntime().availableProcessors() else 0
        lastApp = cpu; lastWall = wall
        return "$r% (this app)"
    }

    private fun thermal(): String {
        if (Build.VERSION.SDK_INT < 29) return "needs Android 10+"
        return listOf("None", "Light", "Moderate", "Severe", "Critical", "Emergency", "Shutdown")
            .getOrElse(getSystemService(PowerManager::class.java).currentThermalStatus) { "?" }
    }

    private fun network(): String {
        val cm = getSystemService(ConnectivityManager::class.java)
        val c = cm.getNetworkCapabilities(cm.activeNetwork) ?: return "offline"
        val t = when { c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"; c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"; else -> "Other" }
        return "$t ${c.linkDownstreamBandwidthKbps / 1000} Mbps"
    }

    private fun copySnapshot() {
        val txt = rows.entries.joinToString("\n") { "${it.key}: ${it.value.text}" }
        getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("PulseDot", txt))
        Toast.makeText(this, "Stats copied", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        h.removeCallbacks(tick); Choreographer.getInstance().removeFrameCallback(frameCb)
        try { wm.removeView(root) } catch (_: Exception) {}
        super.onDestroy()
    }
}
