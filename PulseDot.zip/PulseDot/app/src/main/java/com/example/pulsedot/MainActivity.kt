package com.example.pulsedot

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0F1A22"))
            setPadding((28 * d).toInt(), (64 * d).toInt(), (28 * d).toInt(), (28 * d).toInt())
        }
        fun text(t: String, size: Float, c: String, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = size; setTextColor(Color.parseColor(c))
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, (12 * d).toInt())
        }
        fun btn(t: String, bg: String, onClick: () -> Unit) = Button(this).apply {
            text = t; setTextColor(Color.parseColor("#0F1A22")); setBackgroundColor(Color.parseColor(bg))
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(-1, (52 * d).toInt()).apply { topMargin = (10 * d).toInt() }
        }
        col.addView(text("PulseDot", 36f, "#FFB347", true))
        col.addView(text("A floating dot that shows your phone's FPS, temperature, CPU, RAM and battery on top of any app. Tap the dot to open the mini screen. Long-press it to change what the dot shows. Drag it anywhere.", 16f, "#C9D7DE"))
        status = text("", 15f, "#7FE0D0", true)
        col.addView(status)
        col.addView(btn("1. Allow display over other apps", "#7FE0D0") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(btn("2. Start the dot", "#FFB347") { start() })
        col.addView(btn("Stop the dot", "#E8E8E8") { stopService(Intent(this, OverlayService::class.java)); refresh() })
        setContentView(col)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) { refresh(); return }
        startForegroundService(Intent(this, OverlayService::class.java))
        refresh()
        moveTaskToBack(true)
    }

    private fun refresh() {
        status.text = if (Settings.canDrawOverlays(this)) "Overlay permission: granted" else "Overlay permission: not granted yet (do step 1)"
    }

    override fun onResume() { super.onResume(); refresh() }
}
