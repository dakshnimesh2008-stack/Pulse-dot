PulseDot - floating performance dot (Android)
Build: open this folder in Android Studio (Koala or newer), let Gradle sync, press Run on your phone.
Or: Build > Build APK(s), then install the APK.
First run: tap "Allow display over other apps", enable PulseDot, come back, tap "Start the dot".
Dot: tap = open mini screen, long-press = change what the dot shows (FPS / temp / CPU / RAM), drag = move.
